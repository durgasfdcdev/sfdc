({
    updateArticle : function(component, event) {
        var updateArticleAction = component.get("c.deleteOrArchiveKnowledgeArticle");
        component.set("v.isError", false);
        
        //Set update action parameter
        updateArticleAction.setParams({
            kvaId: component.get("v.recordId"),
            actionType: "Archive"
        });

        //Call deleteDraftAndArchiveKnowledgeArticle controller method to update the Article.
        updateArticleAction.setCallback(this, function(response) {
            console.log('Response: ' + JSON.stringify(response));
            let state = response.getState();
            let updateArticleResult = response.getReturnValue()
            component.set("v.showResult", true);

            if (state === "SUCCESS"){
                component.set("v.articleUpdateMessage", updateArticleResult.message);
                if (updateArticleResult && updateArticleResult.status === 'Succes')
                {
                    component.set("v.isSuccess", true);
                }
            } else {
                component.set("v.isSuccess", false);
            }
        });

        $A.enqueueAction(updateArticleAction);
    },
})