({
    handleUpdateArticle : function(component, event, helper) {
        helper.updateArticle(component, event);
    },

    handleExit : function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();;
    },
})