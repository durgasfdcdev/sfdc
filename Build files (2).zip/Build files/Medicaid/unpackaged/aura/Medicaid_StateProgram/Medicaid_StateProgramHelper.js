({
    initAction : function(component, event, helper)
    {
        let action = component.get("c.getPicklistMap");
        action.setCallback(this, function(response) 
        {
            let state = response.getState();
            let resp = response.getReturnValue();
            console.log('Dependent picklist values: ' + JSON.stringify(resp));

            if (state === "SUCCESS")
            {
                component.set('v.picklistMap', resp);
                helper.getParentRecordId(component, event, helper);
            }
            else 
            {
                this.showToast( 'Error in getting state program dependent picklist values','error','Error' );  
            }
        });

        $A.enqueueAction(action);
    },

    getParentRecordId : function(component, event, helper){
        var pageRef = component.get("v.pageReference");
        console.log(JSON.stringify(pageRef));
        var state = pageRef.state; // state holds any query params
        console.log('state = ' + JSON.stringify(state));
        var base64Context = state.inContextOfRef;
        console.log('base64Context = ' + base64Context);

        if (base64Context.startsWith("1\.")) {
            base64Context = base64Context.substring(2);
            console.log('base64Context = '+base64Context);
        }

        var addressableContext = JSON.parse(window.atob(base64Context));
        var parentRecordId = addressableContext.attributes.recordId;
        console.log('addressableContext = ' + JSON.stringify(addressableContext));
        console.log('parentRecordId = ' + parentRecordId);
        //component.set("v.recordId", addressableContext.attributes.recordId);
        
        if (parentRecordId)
            {
                component.set('v.ParentRecordId' , parentRecordId);
                component.set('v.LabelerCode' , parentRecordId);
                
                let action = component.get("c.getMedicaidLabeler");
                action.setParams({
                    'parentRecordId': parentRecordId
                });

                action.setCallback(this, function(response) {
                    let state = response.getState();
                    let resp = response.getReturnValue();
                    console.log('Labeler Code Response: ' + JSON.stringify(resp));
                    if (state === "SUCCESS")
                    {
                        if (resp && resp.Medicaid_State__r && resp.Medicaid_State__r.Name)
                        {
                            let state = resp.Medicaid_State__r.Name;
                            component.set('v.State' , state);
                            helper.stateChangeAction(component, event, helper);
                        }
                    }
                    else 
                    {
                        this.showToast( 'Error in getting Labeler details', 'error', 'Error' );  
                    }
                });

                $A.enqueueAction(action);
            }
    }, 

    stateChangeAction : function(component, event, helper) 
    {
        let State = component.get('v.State');
        let picklistMap = component.get('v.picklistMap');
        let programNameList = picklistMap[State];
        let plValues = [];
        
        if (programNameList)
        {
            for (let i = 0; i < programNameList.length; i++) {
                plValues.push({
                    label: programNameList[i],
                    value: programNameList[i]
                });
            }
        }
        
        component.set('v.programListOptions', plValues);
        component.set('v.selectedProgramList', []);
        
    },

	saveAction : function(component, event, helper) 
    {
        let LabelerCode = component.get('v.LabelerCode');
        let State = component.get('v.State');
        let StateCode = component.get('v.StateCode');
        let ProgramYear = component.get('v.ProgramYear');
        let Quarter = component.get('v.Quarter');
        let selectedProgramList = component.get('v.selectedProgramList');
        console.log(LabelerCode);
        console.log(selectedProgramList);
        
        let action = component.get("c.createData");
        action.setParams({
            'LabelerCode': LabelerCode,
            'State': State,
            'StateCode': StateCode,
            'ProgramYear': ProgramYear,
            'Quarter': Quarter,
            'selectedProgramList': selectedProgramList,
        });

        action.setCallback(this, function(response) {
            let state = response.getState();
            if (state === "SUCCESS") 
            {
                console.log('Result--'+response.getReturnValue());
                component.set('v.showLoadingSpinner', false);
                this.showToast( 'Order Successfully Created','success','Success' );
                helper.cancelAction(component, event, helper);
            }
            else if (state === "INCOMPLETE") 
            {
                component.set('v.showLoadingSpinner', false);
                // do something
            }
            else if (state === "ERROR") 
            {
                component.set('v.showLoadingSpinner', false);
                let errors = response.getError();
                if (errors) 
                {
                    if (errors[0] && errors[0].message) 
                    {
                        console.log("Error message: " + errors[0].message);
                        this.showToast( errors[0].message,'error','Error' );            
                    }
                } 
                else 
                {
                    component.set('v.showLoadingSpinner', false);
                    this.showToast( 'Unknown error','error','Error' );  
                    console.log("Unknown error");
                }
            }
        });
        
        $A.enqueueAction(action);
	},

    cancelAction : function(component, event, helper) {
        let parentRecordId = component.get('v.ParentRecordId');
        if (parentRecordId)
        {
            let urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/"+parentRecordId
            });
            urlEvent.fire(); 
        }
    },

    getParameterByName: function(component, event, name) {
        name = name.replace(/[\[\]]/g, "\\$&");
        let url = window.location.href;
        let regex = new RegExp("[?&]" + name + "(=1\.([^&#]*)|&|#|$)");
        let results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },

    showToast : function(msgToast,typeToast,titleToast) {
        let toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : titleToast,
            message: msgToast,
            duration:' 5000',
            key: 'info_alt',
            type: typeToast,
            mode: 'pester'
        });
        toastEvent.fire();
    }
})