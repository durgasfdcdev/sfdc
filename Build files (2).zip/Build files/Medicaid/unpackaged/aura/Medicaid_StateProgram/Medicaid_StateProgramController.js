({
  doInit: function (component, event, helper) {
    helper.initAction(component, event, helper);
  },

  handleStateChange: function (component, event, helper) {
    helper.stateChangeAction(component, event, helper);
  },

  saveAction: function (component, event, helper) {
    helper.saveAction(component, event, helper);
  },

  cancelAction: function (component, event, helper) {
    helper.cancelAction(component, event, helper);
  },

  handlePageChange : function(component, event, helper) {
    $A.get('e.force:refreshView').fire();
  },
})