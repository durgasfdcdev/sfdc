({
    getArticleDetails : function(component, event) {
        var articleAction = component.get("c.getKnowledgeArticleDetails");
        
        //Set archive action parameter
        articleAction.setParams({
            articleVersionId: component.get("v.recordId")
        });

        //Call deleteOrArchiveKnowledgeArticle controller method to update the Article.
        articleAction.setCallback(this, function(response) {
            console.log('Response: ' + JSON.stringify(response));
            let state = response.getState();
            let archiveArticleResult = response.getReturnValue()
            console.log('Response Return Value: ' + JSON.stringify(archiveArticleResult));
            component.set("v.showResult", true);

            if (state === "SUCCESS"){
                
                if (archiveArticleResult && archiveArticleResult.status === 'Success')
                {
                    component.set("v.popupMessage", 'Are you sure you want to archive this Article?');
                    component.set("v.showOkButton", false);
                    component.set("v.isSuccess", true);
                    component.set("v.refreshViewId", archiveArticleResult.redirectUrlId);
                    component.set("v.knowledgeArticleId", archiveArticleResult.knowledgeArticleId);
                    component.set("v.articleTitle", archiveArticleResult.articleTitle);
                    component.set("v.allKnowledgeArticles", archiveArticleResult.knowledgeArticles);
                }
                else 
                {
                    component.set("v.popupMessage", archiveArticleResult.message);
                    component.set("v.showOkButton", true);
                    component.set("v.isSuccess", false);

                    if (archiveArticleResult.articleTitle)
                    {   
                        component.set("v.articleTitle", archiveArticleResult.articleTitle);
                    }
                }
            } else {
                component.set("v.popupMessage", archiveArticleResult.message);
                component.set("v.showOkButton", true);
                component.set("v.isSuccess", false);
            }
        });

        $A.enqueueAction(articleAction);
    },

    archiveArticle : function(component, event) {
        var archiveArticleAction = component.get("c.archiveKnowledgeArticle");
        
        //Set archive action parameter
        archiveArticleAction.setParams({
            articleId: component.get("v.knowledgeArticleId"),
            knowledgeArticles: component.get("v.allKnowledgeArticles")
        });

        //Call deleteOrArchiveKnowledgeArticle controller method to update the Article.
        archiveArticleAction.setCallback(this, function(response) {
            console.log('Response: ' + JSON.stringify(response));
            let state = response.getState();
            let archiveArticleResult = response.getReturnValue()
            console.log('Response Return Value: ' + JSON.stringify(archiveArticleResult));
            component.set("v.showOkButton", true);

            if (state === "SUCCESS"){
                component.set("v.popupMessage", archiveArticleResult.message);
                if (archiveArticleResult && archiveArticleResult.status === 'Success')
                {
                    component.set("v.isSuccess", true);
                    if (archiveArticleResult.redirectUrlId)
                    {
                        component.set("v.refreshViewId", archiveArticleResult.redirectUrlId);
                        component.set("v.refreshViewWithVersionNumber", true);
                        component.set("v.refreshView", false);
                    }
                    else{
                        component.set("v.refreshView", true);
                        component.set("v.refreshViewWithVersionNumber", false);
                    }
                }
                else 
                {
                    component.set("v.isSuccess", false);
                    component.set("v.refreshViewWithVersionNumber", false);
                    component.set("v.refreshView", false);
                }
            } else {
                component.set("v.isSuccess", false);
                component.set("v.refreshViewWithVersionNumber", false);
                component.set("v.refreshView", false);
            }
        });

        $A.enqueueAction(archiveArticleAction);
    },
})