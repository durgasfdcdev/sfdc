({
    doInit : function(component, event, helper) {
        helper.getArticleDetails(component, event);
    },

    handleArchiveArticle : function(component, event, helper) {
        helper.archiveArticle(component, event);
    },

    handleExit : function(component, event, helper) {
        let doRefreshView = component.get("v.refreshView");
        let doRefreshViewWithId = component.get("v.refreshViewWithVersionNumber");
        let urlRedirect= $A.get("e.force:navigateToURL");
        if (doRefreshView)
        {
            $A.get('e.force:refreshView').fire();
        }
        else if (doRefreshViewWithId)
        {
            urlRedirect.setParams({
                "url": "/" + component.get("v.refreshViewId")
            });
            urlRedirect.fire();
        }
        $A.get("e.force:closeQuickAction").fire();;
    },
})