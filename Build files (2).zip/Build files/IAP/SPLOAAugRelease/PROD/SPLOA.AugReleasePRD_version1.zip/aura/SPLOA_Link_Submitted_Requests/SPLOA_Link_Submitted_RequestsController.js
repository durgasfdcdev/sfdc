({
    doInit : function(component, event, helper) {
        var action = component.get("c.fetchUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                // set current user information on userInfo attribute
                console.log('storeResponse*****'+storeResponse);
                if (storeResponse== true) {
                    console.log('Entering*****');
                    component.set("v.ViewOnlyUser", true);  
                    component.set("v.showView",false);
                } else {                    
                    component.set("v.ViewOnlyUser", false);      
                    component.set("v.showView",true);
                }
                //component.set("v.userInfo", storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    Search: function(component, event, helper) {
        var searchField = component.find('searchField');
        var isValueMissing = searchField.get('v.validity').valueMissing;
        // if value is missing show error message and focus on field
        if(isValueMissing) {
            searchField.showHelpMessageIfInvalid();
            searchField.focus();
        }else{
            // else call helper function 
            helper.SearchHelper(component, event);
        }
    },
    selectAll: function(component,event, helper){
        var slctCheck = event.getSource().get("v.value");
        var getCheckAllId = component.find("cboxRow");
        
        if (slctCheck == true) {
            for (var i = 0; i < getCheckAllId.length; i++) {
                component.find("cboxRow")[i].set("v.value", true);                   
            }
        } else {
            for (var i = 0; i < getCheckAllId.length; i++) {
                component.find("cboxRow")[i].set("v.value", false);                
            }
        }
    },
    changeSelectAll:function(component,event, helper){
        console.log('entering');
        component.set("v.isButtonActive", false);
        var slctCheckRow = event.getSource().get("v.value");
        var getCheckAllId = component.find("cbox");
        if(slctCheckRow == false) {
            component.find("cbox").set("v.value", false);
            component.set("v.isButtonActive", true);
        }       
    },
    linkRequest: function(component,event,helper) {
        var getCheckAllId = component.find("cboxRow");
        var recordId = component.get('v.recordId');
        console.log('getCheckAllId*****'+getCheckAllId.length);
        var selctedRec = [];
        if(getCheckAllId.length>1){
            for (var i = 0; i < getCheckAllId.length; i++) {
                console.log('inside loop*****'+selctedRec);
                if(getCheckAllId[i].get("v.value") == true )
                {
                    selctedRec.push(getCheckAllId[i].get("v.text")); 
                }
            }
        }
        else{
            if(getCheckAllId.get("v.value") == true )
            {
                selctedRec.push(getCheckAllId.get("v.text")); 
            }
        }
        helper.link_Selected(component,event,selctedRec,recordId);
    }
})